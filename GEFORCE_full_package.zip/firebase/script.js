import { initializeApp } from "https://www.gstatic.com/firebasejs/10.9.0/firebase-app.js";
import { getFirestore, collection, doc, setDoc, getDocs, onSnapshot, updateDoc } from "https://www.gstatic.com/firebasejs/10.9.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA9az5M2O2p9dP-gWQaNEnb7iWz4ik89eg",
  authDomain: "hhjjb-48c90.firebaseapp.com",
  projectId: "hhjjb-48c90",
  storageBucket: "hhjjb-48c90.firebasestorage.app",
  messagingSenderId: "507778529162",
  appId: "1:507778529162:web:308976e239e786e899fa73",
  measurementId: "G-HTW846WQKR"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const groupRef = collection(db, "groups");

const groupList = document.getElementById("groupList");
const groupInput = document.createElement("input");
groupInput.id = "groupInput";
groupInput.placeholder = "Add Group";
groupInput.style.width = "100%";

const urlInput = document.createElement("input");
urlInput.id = "urlInput";
urlInput.placeholder = "Paste URL and press Enter";
urlInput.style.width = "100%";

const addGroupBtn = document.createElement("button");
addGroupBtn.id = "addGroup";
addGroupBtn.textContent = "+";
groupList.parentElement.insertBefore(groupInput, groupList);
groupList.parentElement.insertBefore(addGroupBtn, groupList.nextSibling);
document.querySelector(".main").insertBefore(urlInput, document.getElementById("openUrls"));

async function renderGroups() {
  const snapshot = await getDocs(groupRef);
  groupList.innerHTML = "";
  snapshot.forEach(doc => {
    const group = doc.data();
    const li = document.createElement("li");
    li.innerHTML = `
      <strong>${group.name}</strong>
      <ul>${(group.urls || []).map(url => `<li><a href="${url}" target="_blank">${url}</a></li>`).join("")}</ul>
    `;
    groupList.appendChild(li);
  });
}

onSnapshot(groupRef, renderGroups);

addGroupBtn.addEventListener("click", async () => {
  const name = groupInput.value.trim();
  if (!name) return;
  const newId = name.toLowerCase().replace(/\s+/g, "-");
  await setDoc(doc(groupRef, newId), { name, urls: [] });
  groupInput.value = "";
});

urlInput.addEventListener("keypress", async (e) => {
  if (e.key === "Enter") {
    const url = urlInput.value.trim();
    if (!url) return;

    const docs = await getDocs(groupRef);
    let lastDoc = null;
    docs.forEach(doc => lastDoc = doc);
    if (lastDoc) {
      const group = lastDoc.data();
      const updatedUrls = [...(group.urls || []), url];
      await updateDoc(doc(groupRef, lastDoc.id), { ...group, urls: updatedUrls });
      urlInput.value = "";
    }
  }
});

document.getElementById("openUrls").addEventListener("click", async () => {
  const snapshot = await getDocs(groupRef);
  snapshot.forEach(doc => {
    const group = doc.data();
    (group.urls || []).forEach(url => window.open(url, "_blank"));
  });
});

document.getElementById("toggleTheme").addEventListener("click", () => {
  document.body.classList.toggle("dark-theme");
});
